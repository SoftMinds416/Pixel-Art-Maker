# Pixel Art Maker Project

!

# About:
This Project File contains Code for [Pixel Art Maker](http://logan1x.me/PixelArtMaker/) project done for udacity nanodegree.
This is a web App that allows Users to draw "Pixel Art" on a canvas(background) customizable to terms of the user! 
The aim of the "Pixel Art Maker" project aims at building amazing colorful Art from a Selection of grids where a user can select Gride size (height and width numbers) and color(s) into different cells of the grid.


## Special Interest:
The Pixel Art Maker Project brings to Mind the Mortal Combat, Sper Mario and Nitendo videogames Consoles in the 80's.
Some Persons did have to oppotunity to or probably may not have been given Birth to, But Huge Tahanks to UDACITY for making us creat this Web App for such fun and thrill.


## Screenshot:
Here are some samples screenshots to see how website looks like:
<p align="center">
        <img scr="images/.......jpeg" title=
             
</p>            




# Instructions & Requirements
Schoolar are required to download the starter code from the udacity git hub repositoty - 
The Pixel Art Maker repository on GitHub
https://github.com/udacity/project-pixel-art-maker-starter

This zipped folder
https://github.com/udacity/project-pixel-art-maker-starter/archive/master.zip

## Contributing
This repository is the starter code for all Udacity shoolars and thus, likely not be accepting pull requests.   

##Extra Feature##
## Remove Grid and Clear Color
!Click the "Remove Grid" and the "Clear Color" buttons to remove any grids and designed pattern with colors already created.    

## Going the Udacity Way
It's been a whole world of experiences, Learning, networking and committing to knowing and researching. It may not have been easy as thought 
initially before the commencement of this journey, but it has been wortH it. With a community of "one-teach-one", learning the rudiments of Basic Web developments, 
Coding using DOMs, jQuery and Java scripts in websites is facinating even when at some point one is left with not option of dozing off on his "coding desk".

## Special Thanks
It will be a deservice not to words, this Lofty and Noteworthy initiative by:

[Udacity»](www.udacity.com),
[Google»](www.google.com), and  
[Andela Leraning Community»](https://andela.com)

It's my Prayer and Wish that this initiave out-live us and so many much more African benefit and make the World a better place.

## Author:
[SoftMinds416»](https://github.com/BenEmdon)
[Slack_Handle»] for the [ALC with Google 3.0](alcwithgoogle3.slack.com) is SoftMinds416 ()